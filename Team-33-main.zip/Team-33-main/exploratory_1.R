# Load necessary libraries
library(tidyverse)
install.packages("corrplot")
library(corrplot)

# Load the data
data <- read.csv("marketing_score.csv")

# 1. Summary Statistics and checks
summary(data)

sum(is.na(data))

# convert categorical variables to factors - one hot
data$Gender <- as.factor(data$Gender)
data$Marital_Status <- as.factor(data$Marital_Status)
data$Product_Category <- as.factor(data$Product_Category)
data$Customer_Loyalty_Level <- as.factor(data$Customer_Loyalty_Level)

# continuous variables list 
continuous_vars <- c("Customer_Age", "Annual_Income", "Spending_Score", 
                     "Online_Shopping_Frequency", "In_Store_Shopping_Frequency", 
                     "Promotional_Emails_Opened", "Website_Visits_Last_Month", 
                     "Total_Purchases_Last_Year", "Product_Review_Score", 
                     "Social_Media_Engagement", "Referral_Score", 
                     "Customer_Lifetime_Value")

#histograms for numeric data
par(mfrow = c(3, 4))  
for (var in continuous_vars) {
  hist(data[[var]], main = paste("Histogram of", var), xlab = var, col = "skyblue", border = "white")
}
par(mfrow = c(1, 1))  


# log- transform skewed variables  
data <- data %>%
  mutate(
    Annual_Income_log = log(Annual_Income + 1),
    Social_Media_Engagement_log = log(Social_Media_Engagement + 1),
    In_Store_Shopping_Frequency_log = log(In_Store_Shopping_Frequency + 1),
    Total_Purchases_Last_Year_log = log(Total_Purchases_Last_Year + 1),
    Customer_Lifetime_Value_log = log(Customer_Lifetime_Value + 1)
  )

# Check the summary of transformed variables
summary(data[, c("Annual_Income_log", "Social_Media_Engagement_log", 
                 "In_Store_Shopping_Frequency_log", "Total_Purchases_Last_Year_log", 
                 "Customer_Lifetime_Value_log")])


#correlation analysis
log_vars <- data %>%
  select(Annual_Income_log, Social_Media_Engagement_log, 
         In_Store_Shopping_Frequency_log, Total_Purchases_Last_Year_log, 
         Customer_Lifetime_Value_log)


cor_matrix_log <- cor(log_vars, use = "complete.obs")
corrplot(cor_matrix_log, method = "color", type = "upper", tl.col = "black", tl.srt = 45)



# log-transformed histograms
par(mfrow = c(2, 3))  
for (var in names(log_vars)) {
  hist(log_vars[[var]], main = paste("Histogram of", var), xlab = var, col = "skyblue", border = "white")
}
par(mfrow = c(1, 1))  


#linear fitting
log_model <- lm(Customer_Lifetime_Value_log ~ Annual_Income_log + 
                  Social_Media_Engagement_log + In_Store_Shopping_Frequency_log + 
                  Total_Purchases_Last_Year_log, data = data)

summary(log_model)

# Residuals vs Fitted Values Plot (Homoscedasticity)
plot(log_model$fitted.values, log_model$residuals, 
     xlab = "Fitted Values", ylab = "Residuals", 
     main = "Residuals vs Fitted Values")
abline(h = 0, col = "red", lwd = 2)

# Q-Q Plot
qqnorm(log_model$residuals, main = "Q-Q Plot of Residuals")
qqline(log_model$residuals, col = "red", lwd = 2)

# Histogram
hist(log_model$residuals, breaks = 30, main = "Histogram of Residuals", 
     xlab = "Residuals", col = "lightblue")


