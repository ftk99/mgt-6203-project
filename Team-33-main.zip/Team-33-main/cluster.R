# Install required packages
install.packages(c("tidyverse", "ggplot2"))
library(tidyverse)
library(ggplot2)

# Load the dataset
data <- read.csv("marketing_score.csv")

# Convert categorical variables to factors
data$Gender <- as.factor(data$Gender)
data$Marital_Status <- as.factor(data$Marital_Status)
data$Product_Category <- as.factor(data$Product_Category)
data$Customer_Loyalty_Level <- as.factor(data$Customer_Loyalty_Level)

# Apply log transformations to skewed variables
data <- data %>%
  mutate(
    Annual_Income_log = log(Annual_Income + 1),
    Social_Media_Engagement_log = log(Social_Media_Engagement + 1),
    In_Store_Shopping_Frequency_log = log(In_Store_Shopping_Frequency + 1),
    Total_Purchases_Last_Year_log = log(Total_Purchases_Last_Year + 1),
    Customer_Lifetime_Value_log = log(Customer_Lifetime_Value + 1)
  )

# Select only the relevant variables for clustering
cluster_data <- data %>%
  select(Annual_Income_log, Social_Media_Engagement_log, 
         In_Store_Shopping_Frequency_log, Total_Purchases_Last_Year_log, 
         Customer_Lifetime_Value_log)
# Scale the data for clustering
scaled_data <- scale(cluster_data)

# Determine the optimal number of clusters using the elbow method
set.seed(123)  # Ensure reproducibility
wss <- sapply(1:10, function(k) {
  kmeans(scaled_data, centers = k, nstart = 10)$tot.withinss
})

# Plot the elbow method
plot(1:10, wss, type = "b", pch = 19, frame = FALSE,
     xlab = "Number of Clusters (k)", ylab = "Total Within-Cluster Sum of Squares",
     main = "Elbow Method for Optimal k")

# Apply K-Means clustering
set.seed(123)
kmeans_result <- kmeans(scaled_data, centers = 4, nstart = 10)

# Add the cluster assignments to the original dataset
data$cluster <- kmeans_result$cluster
# Summarize cluster characteristics
cluster_summary <- data %>%
  group_by(cluster) %>%
  summarise(
    Avg_Annual_Income = mean(Annual_Income_log, na.rm = TRUE),
    Avg_Social_Media_Engagement = mean(Social_Media_Engagement_log, na.rm = TRUE),
    Avg_Shopping_Frequency = mean(In_Store_Shopping_Frequency_log, na.rm = TRUE),
    Avg_Purchases = mean(Total_Purchases_Last_Year_log, na.rm = TRUE),
    Avg_CLV = mean(Customer_Lifetime_Value_log, na.rm = TRUE)
  )
print(cluster_summary)
# Plot clusters (e.g., Annual_Income_log vs. Customer_Lifetime_Value_log)
ggplot(data, aes(x = Annual_Income_log, y = Customer_Lifetime_Value_log, color = factor(cluster))) +
  geom_point() +
  labs(title = "Customer Clusters", color = "Cluster") +
  theme_minimal()

# Another example: Social_Media_Engagement_log vs CLV
ggplot(data, aes(x = Social_Media_Engagement_log, y = Customer_Lifetime_Value_log, color = factor(cluster))) +
  geom_point() +
  labs(title = "Customer Clusters", color = "Cluster") +
  theme_minimal()
